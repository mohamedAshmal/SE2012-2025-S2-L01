import java.util.Scanner;

public class MarksEasy {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Number of students: ");
        int n = sc.nextInt();

        int[][] marks = new int[n][3]; 
        String[] subjects = {"Maths", "Chemistry", "Physics"};

        
        for (int i = 0; i < n; i++) {
            System.out.println("\nStudent " + (i + 1) + " marks:");
            for (int j = 0; j < 3; j++) {
                System.out.print(subjects[j] + ": ");
                marks[i][j] = sc.nextInt();
            }
        }

        
        for (int i = 0; i < n; i++) {
            System.out.println("\n--- Student " + (i + 1) + " ---");

            int total = 0;
            for (int j = 0; j < 3; j++) {
                int m = marks[i][j];
                total += m;
                System.out.print(subjects[j] + " (" + m + "): ");

                
                if (m >= 90) System.out.println("A");
                else if (m >= 80) System.out.println("B");
                else if (m >= 70) System.out.println("C");
                else if (m >= 60) System.out.println("D");
                else System.out.println("Fail");
            }

            float avg = total / 3.0f;
            System.out.println("Total: " + total);
            System.out.println("Average: " + avg);
        }

        sc.close();
    }
}