import java.util.Scanner;

public class Welcome{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter your First Name: ");
        String firstName = scanner.nextLine();

        
        System.out.print("Enter your Last Name: ");
        String lastName = scanner.nextLine();

        
        System.out.println("Welcome to the Second Year <> " + firstName + " " + lastName + " <>");

        scanner.close();
    }
}
